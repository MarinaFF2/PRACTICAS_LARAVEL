<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class micontrolador extends Controller {

    public function indice() {
        return view('principal');
    }

    //valida un formulario
    public function valida(Request $req) {
        $n1 = $req->get('n1');
        $n2 = $req->get('n2');
        if (null != $req->get('sum')) {
            $result = $n1 + $n2;
            $oper = '+';
        }
        if (null != $req->get('res')) {
            $result = $n1 - $n2;
            $oper = '-';
        }
        if (null != $req->get('mult')) {
            $result = $n1 * $n2;
            $oper = '*';
        }
        if (null != $req->get('div')) {
            $oper = '/';
            if ($n2 == 0) {
                $result = 'no se pudo dividir, porque el divisor es 0';       
            } else {
                $result = $n1 / $n2;
            }
        }
        //vector asociativo
        $datos = [
            'dato1' => $n1,
            'dato2' => $n2,
            'dato3' => $oper,
            'dato4' => $result
        ];
        //se lo pasamos a una vista
        return view('vista', $datos);
    }

    public function ruta() {
        
    }

}
