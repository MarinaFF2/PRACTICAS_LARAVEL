<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->

    </head>
    <body>
        <?php
        echo $dato1.' '.$dato3.' '.$dato2.' = '.$dato4;
        ?>
        <br>
        <a href="enlace">Volver</a>
    </body>
</html>
<?php /**PATH /var/www/html/laravel/calculadora/resources/views/vista.blade.php ENDPATH**/ ?>