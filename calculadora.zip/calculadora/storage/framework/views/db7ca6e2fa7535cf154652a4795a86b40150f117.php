<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        
    </head>
    <body>
        <form name="ejemplo" action="validar" method="POST">
            <?php echo e(csrf_field()); ?>

            <p>N1</p><input type="number" name="n1" value="0">
            <p>N2</p><input type="number" name="n2" value="0">
            <br><br>
            <input type="submit" name="sum" value="+">
            <input type="submit" name="res" value="-">
            <input type="submit" name="mult" value="*">
            <input type="submit" name="div" value="/">
        </form>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\html\laravel\calculadora\resources\views/principal.blade.php ENDPATH**/ ?>