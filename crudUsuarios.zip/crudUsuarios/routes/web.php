<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','micontrolador@indice');
Route::post('inicioSesion','micontrolador@inicioSesion');
Route::post('registrarse','micontrolador@registrar');
Route::post('crudUsuario','micontrolador@crudUsuario');
Route::post('olvidarPwd','micontrolador@olvidarPwd');
Route::post('elegirRol','micontrolador@elegirRol');

//enlaces
Route::get('registrarse','micontrolador@redirigirRegistarse');
Route::get('principal','micontrolador@indice');
Route::get('olvidarContrasenia','micontrolador@olvidarContrasenia');
