<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

        <!-- Course CSS -->
<!--        <link rel="stylesheet" type="text/css" href="../../css/css_general.css" media="screen" />        
        <link rel="stylesheet" type="text/css" href="../../css/css_tabla.css" media="screen" />-->

<!--        <script src="../../jquery-3.4.1.min.js"></script>-->
        <!--<script src="../js/registrarse.js"></script>-->
    </head>
    <body>
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

        <div class="container">  
            <div class="row">
                <div class="col-sm col-md col-lg">
                    <div class="breadcrumb">
                        <div class="breadcrumb-item"><a href="elegirRol">Home</a></div>
                        <div class="breadcrumb-item active">Crud Usuario</div>
                    </div>   
                </div>
            </div>
            <div class="row">
                <div class="col-sm col-md col-lg">
                    <h2 class="text-center">Gestión de usuarios</h2>
                    <div class="table-responsive ">
                        <table class="table table-striped table-hover table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Correo</th>
                                    <th>Nombre</th>
                                    <th>Apellido</th>
                                    <th>Rol</th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $v = Conexion::obtenerUsuarios();
                                foreach ($v as $key) {
                                    ?>
                                <form class="form-inline" action="crudUsuario" method="POST">
                                    {{ csrf_field() }}
                                    <tr>
                                        <td><input type="email" class="in" class="form-control form-control-sm form-control-md form-control-lg" name="correo" value="<?php echo $key->getCorreo(); ?>" readonly/></td>
                                        <td><input type="text" class="in" class="form-control form-control-sm form-control-md form-control-lg" name="nombre" value="<?php echo $key->getNombre(); ?>" pattern="[A-Za-z]{1,50}"/></td>
                                        <td><input type="text" class="in" class="form-control form-control-sm form-control-md form-control-lg" name="apellido" value="<?php echo $key->getApellido(); ?>" pattern="[A-Za-z]{1,50}"/></td>
                                        <?php
                                        if ($key->getRol() == 1) { //esta como adminstrador y hay que cambiarlo a usuario normal
                                            ?>
                                            <td>
                                                <input type="submit" name="rol" value="Usuario"/>
                                            </td>
                                            <?php
                                        } else if ($key->getRol() == 2) {//esta como usuario normal y hay que cambiarlo a adminstrador
                                            ?>
                                            <td>
                                                <input type="submit" name="rol" value="Administrador"/>
                                            </td>
                                            <?php
                                        }
                                        ?>
                                        <td>
                                            <input type="submit" id="eliminar" name="botUsuario" value="X"/>
                                        </td>
                                        <td>
                                            <input type="submit" id="editar" name="botUsuario" value="Editar"/>
                                        </td>
                <!--                                        <td><button type="submit" id="editar" class="btn" name="editar" /></td>
                                                        <td><button type="submit" id="eliminar" class="btn" name="eliminar" /></td>-->
                                    </tr>
                                </form>
                                <?php
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>           
        </div>
    </body>
</html>
