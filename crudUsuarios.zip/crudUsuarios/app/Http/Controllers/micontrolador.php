<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use App\Clase\Modelo\Usuario;
use App\Clase\Auxiliar\Conexion;
use App\Clase\Auxiliar\Email;

class micontrolador extends Controller {

    public function indice() {
        return view('principal');
    }

    public function redirigirRegistarse() {
        return view('registro');
    }

    public function inicioSesion(Request $req) {
        $correo = $req->get('usuario');
        $pass = $req->get('pwd');
        $passHash = md5($pass);
        $u = Conexion::existeUsuario($correo, $passHash);
        if ($u != null) {
            session()->put('usu', $u);
            session()->put('cor', $u->getCorreo());
            if ($u->getRol() == 0) { //si eres jugador
                return view('bienvenidaUsuario');
            }
            if ($u->getRol() == 1) { //si eres administrador
                return view('elegirRol');
            }
        } else {
            echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                    Error al introducir los datos vuelve a intentarlo.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
            return view('principal');
        }
    }

    public function elegirRol(Request $req) {
        if ($req->get('botRol') == "admin") {
            return view('crudUsuario');
        } else {
            return view('bienvenidaUsuario');
        }
    }

    public function olvidarPwd(Request $req) {
        $para = $req->get('correo');
        Email::enviarCorreo($para);
        //comprobar que redireciona bien la pagina
    }

    public function registrar(Request $req) {
        $correo = $req->get('correo');
        $pass = $req->get('clave');
        $repass = $req->get('reclave');
        if ($pass == $repass) {
            $passHash = md5($pass); //si esta bien codificada devuelve true
            $u = Conexion::existeUsu($correo);
            if ($u == null) { //solo funciona si es diferente de null, porque no detecta que esta vacio
                $nom = $req->get('nombre');
                $ape = $req->get('apellido');
                Conexion::insertarUsuarios($correo, $passHash, $nom, $ape);
                Conexion::insertarRol($correo, 0);
                echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                    Te has registrado correctamente.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
                return view('principal');
            }
        } else {
            echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                    Error al registrarse, vuelve a intentarlo.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
            return view('registro');
        }
    }

    //Controlador del crud de usuarios
    public function crudUsuario(Request $req) {
        if (isset($_REQUEST['botUsuario'])) {
            //cuando editas a un usuario
            if ($req->get('botUsuario') == 'Editar') {
                $correo = $req->get('correo');
                $nombre = $req->get('nombre');
                $apellido = $req->get('apellido');
                Conexion::ModificarUsuarios($correo, $nombre, $apellido);
                echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                    Sea ha modificado correctamente el usuario.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
                return view('crudUsuario');
            }

            //Cuando eliminas a un usuario
            if ($req->get('botUsuario') == 'X') {
                $correo = $req->get('correo');
                Conexion::borrarUsuario($correo);
                Conexion::borrarRol($correo);
                echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                    Se a eliminado correctamente el usuario.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
                return view('crudUsuario');
            }
        }
        //cambiar de rol en el crud
        if (isset($_REQUEST['rol'])) {
            if ($req->get('rol') == 'Usuario') { //pasa a ser administrador
                $correo = $req->get('correo');
                Conexion::ModificarRol(2, $correo);
            }
            if ($req->get('rol') == 'Administrador') { //pasa aser usuario
                $correo = $req->get('correo');
                Conexion::ModificarRol(1, $correo);
            }
            echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                    Se a cambiado correctamente de rol.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
            return view('crudUsuario');
        }
    }

}
