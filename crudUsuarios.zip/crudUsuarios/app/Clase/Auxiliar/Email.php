<?php

namespace App\Clase\Auxiliar;

use App\Clase\Auxiliar\Conexion;

/**
 * Description of Email
 *
 * @author daw207
 */
class Email {

    static function enviarCorreo($para) {
        $pwd = Email::generateRandomString(5);
        $pwdBD = md5($pwd);
        //cifro la contraseña generada
        Conexion::ModificarUsuContra($para, $pwdBD);

        $mensaje = "La nueva contraseña para entrar del usuario " . $para . " es: '" . $pwd . "'.";
        $asunto = "Se ha olvidado la contraseña ";
        if (mail($para, $asunto, $mensaje)) {
            echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                   Se ha enviado bien el correo.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
            return view('principal');
        } else {
            echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                    Error al enviar el correo.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
            return view('olvidarPwd');
        }
    }

    /**
     * Genera la contraseña
     * @param type $length
     * @return type
     */
    public static function generateRandomString($length) {
        return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length);
    }

}
