<?php

namespace App\Clase\Auxiliar;
use App\Clase\Modal\Usuario;

/**
 * Description of Conexion
 *
 * @author daw207
 */
class Conexion {
    /**
     * CLASE USUARIOS
     */

    /**
     * Metodo para obtener un usuario para comprobar que exite
     * con el correo y contraseña para el incio de sesion
     * @return \Usuario
     */
    static function existeUsuario($correo, $pwd) {
//        $sql = 'SELECT usuario.correo, usuario.pwd, usuario.nombre, usuario.apellido, asignarRol.idRol FROM usuario,asignarRol where usuario.correo=? and usuario.pwd=? and asignarRol.usuario=usuario.correo';
        $u = \DB::table('usuario')
                ->join('asignarRol', 'asignarRol.usuario', '=', 'usuario.correo')
                ->select('usuario.correo', 'usuario.pwd', 'usuario.nombre', 'usuario.apellido', 'asignarRol.idRol')
                ->where('usuario.correo', '=', $correo)
                ->where('usuario.pwd', '=', $pwd)
                ->get();
        foreach ($u as $us) {
            $usuario = new Usuario($us->correo, $us->pwd, $us->nombre, $us->apellido, $us->idRol);
        }
        return $usuario;
    }

    static function existeUsu($correo) {
//        $sql = 'SELECT usuario.correo, usuario.pwd, usuario.nombre, usuario.apellido, asignarRol.idRol FROM usuario,asignarRol where usuario.correo=? and usuario.pwd=? and asignarRol.usuario=usuario.correo';
        $u = \DB::table('usuario')
                ->join('asignarRol', 'asignarRol.usuario', '=', 'usuario.correo')
                ->select('usuario.correo', 'usuario.pwd', 'usuario.nombre', 'usuario.apellido', 'asignarRol.idRol')
                ->where('usuario.correo', '=', $correo)
                ->get();
        $usuario = null;
        if ($u != null) {
            foreach ($u as $us) {
                $usuario = new Usuario($us->correo, $us->pwd, $us->nombre, $us->apellido, $us->idRol);
            }
        }
        return $usuario;
    }

    /**
     * Metodo para obtener una lista de array con la clase usuario
     * @return \Usuario
     */
    static function obtenerUsuarios() {
//        $sql = 'SELECT usuario.correo, usuario.pwd, usuario.nombre, usuario.apellido, asignarRol.idRol FROM usuario,asignarRol where usuario.correo=? and usuario.pwd=? and asignarRol.usuario=usuario.correo';
        $u = \DB::table('usuario')
                ->join('asignarRol', 'asignarRol.usuario', '=', 'usuario.correo')
                ->select('usuario.correo', 'usuario.pwd', 'usuario.nombre', 'usuario.apellido', 'asignarRol.idRol')
                ->get();
        $cont = 0;
        foreach ($u as $us) {
            $usuario = new Usuario($us->correo, $us->pwd, $us->nombre, $us->apellido, $us->idRol);
            $v[$cont] = $usuario;
            $cont++;
        }
        return $v;
    }

    /**
     * METODO INSERTAR USUARIO
     * @param type $correo
     * @param type $pwd
     * @param type $nombre
     * @param type $apellido
     */
    static function insertarUsuarios($correo, $pwd, $nombre, $apellido) {
        \DB::table('usuario')->insert(
                ['correo' => $correo, 'pwd' => $pwd, 'nombre' => $nombre, 'apellido' => $apellido]
        );
//        $sql = 'INSERT INTO usuario (correo, pwd, nombre, apellido) VALUES (?,?,?,?)';
    }

    /**
     * METODO MODIFICAR USUARIO
     * @param type $correo
     * @param type $pwd
     * @param type $nombre
     * @param type $apellido
     */
    static function ModificarUsuarios($correo, $nombre, $apellido) {
        \DB::table('usuario')
                ->where('correo', '=', $correo)
                ->update(['nombre' => $nombre, 'apellido' => $apellido]);
//        $sql = 'UPDATE usuario SET nombre=?, apellido=? where correo=?';
    }

    /**
     * METODO MODIFICAR USUARIO
     * @param type $correo
     * @param type $pwd
     * @param type $nombre
     * @param type $apellido
     */
    static function ModificarUsuContra($correo, $pwd) {
        \DB::table('usuario')
                ->where('correo', '=', $correo)
                ->update(['pwd' => $pwd]);
//        $sql = 'UPDATE usuario SET pwd=? where correo=?';
    }

    /**
     * BORRAR USUARIO   
     * @param type $correo
     */
    static function borrarUsuario($correo) {
        \DB::table('usuario')
                ->where('correo', '=', $correo)
                ->delete();
//         $sql = 'DELETE FROM usuario WHERE correo=?';
    }

    /**
     * CLASE ROL
     */

    /**
     * METODO INSERTAR ROL
     * @param type $correo
     * @param type $rol
     */
    static function insertarRol($correo, $rol) {
//        $sql = 'INSERT INTO asignarRol (idAsignarRol, usuario, idRol) VALUES (0,?,?)';
        \DB::table('asignarRol')->insert(
                ['idAsignarRol' => 0, 'usuario' => $correo, 'idRol' => $rol]
        );
    }

    /**
     * Metodo modificar rol
     * @param type $idAsignarRol
     * @param type $rol
     * @param type $correo
     */
    static function ModificarRol($rol, $correo) {
        \DB::table('asignarRol')
                ->where('usuario', '=', $correo)
                ->update(['idRol' => $rol]);
//        $sql = 'UPDATE asignarRol SET idRol=? WHERE usuario=?';
    }

    /**
     * BORRAR ROL
     * @param type $correo
     */
    static function borrarRol($correo) {
        \DB::table('asignarRol')
                ->where('usuario', '=', $correo)
                ->delete();
//        $sql = 'DELETE FROM asignarRol WHERE usuario = ?';
    }

}
