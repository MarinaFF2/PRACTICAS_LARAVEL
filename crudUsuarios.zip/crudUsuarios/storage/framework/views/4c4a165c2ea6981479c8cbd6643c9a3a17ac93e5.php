<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Course CSS -->
        <!--<link rel="stylesheet" href="styles.css" />-->
        
    </head>
    <body>
        <table>
            <caption>LISTA USUARIOS</caption>
            <thead>
                <tr>
                    <th>CORREO</th>
                    <th>NOMBRE</th>
                    <th>APELLIDO</th>
                    <th>ROL</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $v = Conexion::obtenerUsuarios();
                for ($i = 0; $i < count((array)$v); $i++) {
                    ?>
            <form action="crudUsuario" method="POST">
                <?php echo e(csrf_field()); ?>

                    <tr>
                        <td>
                            <input type="text" name="correo" value="<?php echo $v[$i]->getCorreo(); ?>" readonly/>
                        </td> 
                        <td>
                            <input type="text"  name="nombre" pattern="[A-Za-z]{1,50}" value="<?php echo $v[$i]->getNombre(); ?>"/>
                        </td>   
                        <td>
                            <input type="text"  name="apellido" pattern="[A-Za-z]{1,50}" value="<?php echo $v[$i]->getApellido(); ?>"/>
                        </td>
                        <td>
                            <input type="number" name="rol" min="0" max="1" pattern="[0-9]{1}"value="<?php echo $v[$i]->getRol(); ?>"/>
                        </td>
                        <td>
                            <input type="submit" id="eliminar" name="botUsuario" value="X"/>
                        </td>
                        <td>
                            <input type="submit" id="editar" name="botUsuario" value="Editar"/>
                        </td>
                    </tr>
                </form>
                <?php
            }
            ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH /var/www/html/laravel/crudUsuarios/resources/views/crudUsuario.blade.php ENDPATH**/ ?>