<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
    </head>
    <body>
        <form name="form1" action="validar" method="POST">
            <?php
            $n = $dato1 ;
            ?>
            <?php echo e(csrf_field()); ?>

            La tabla de multiplicar del <input type="text" name="n1" value="<?php echo $n ?>" readonly="true"><br>
            <?php
            for ($i = 0; $i <= 10; $i++) {
                echo $n . ' x ' . $i . ' = ';
                ?>
                <input type="text" name="n[]" value=""><br>
                <?php
            }
            ?>
            <input type="submit" name="comprobar" value="Comprobar">
        </form>
    </body>
</html><?php /**PATH C:\xampp\htdocs\html\laravel\tablaMultiplicar\resources\views/tabla.blade.php ENDPATH**/ ?>