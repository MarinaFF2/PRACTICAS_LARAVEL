<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class micontrolador extends Controller {

    public function indice() {
        return view('principal');
    }

    //multiplicar por x numero
    public function multiplicar(Request $req) {
        $n = $req->get('n1');
        $datos = [
            'dato1' => $n
        ];
        return view('tabla', $datos);
    }

    //validar la multiplicacion
    public function validar(Request $req) {
        $n = $req->get('n1');
        $result = $req->get('n');
        ?>
        <form name="form2" action="volver" method="POST">
            {{ csrf_field() }}
            <?php
            for ($j = 0; $j <= 10; $j++) {
                echo $n . ' x ' . $j . ' = ';
                if ($n * $j == $result[$j]) {
                    ?>
                    <input type="text" name="n[]" style="background-color:green" value="<?php echo $result[$j] ?>"><br>
                    <?php
                } else {
                    ?>
                    <input type="text" name="n[]" style="background-color:red" value="<?php echo $result[$j] ?>"><br>
                    <?php
                }
            }
            ?>
            <input type="submit" name="volver" value="Volver"/>
        </form>
        <?php
        return view('principal');        
    }

}
