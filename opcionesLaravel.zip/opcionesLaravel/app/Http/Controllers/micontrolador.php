<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class micontrolador extends Controller {

    public function Registrarse(Request $req) {
        try {
            $dni = $req->get('dni');
            $nombre = $req->get('nombre');
            $apellido = $req->get('apellido');
            $edad = $req->get('edad');
            \PersonaTableSeeder::run1($dni, $nombre, $apellido, $edad);

            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                        Registrado.
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">X</span>
                        </button>
                      </div>';
        } catch (Exception $e) {
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                        Error.
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">X</span>
                        </button>
                      </div>';
            $this->exceptions->report($e);            
        }
        return redirect(url('principal'));
    }

}
