@extends('maestra')
@section('titulo')
Registro
@endsection
@section('content')
<header
    <h1 class="h1">Registrarse</h1>
</header>
<div class="container">
    <div class="row">
        <div class="col-sm col-md ">
            <form name="registrarse" action="registrarse" method="POST">
                {{ csrf_field() }}
                <div class="row">
                    <div class="col-sm col-md border border-primary ">
                        <div class="form-group">
                            <label class="col-label-sm">DNI:</label>
                            <input type="text" class="form-control form-control-sm" name="dni"/> 
                        </div><div class="form-group">
                            <label class="col-label-sm">Nombre:</label>
                            <input type="text" class="form-control form-control-sm" name="nombre" placeholder="Nombre" pattern="[A-Za-z]{1,50}"/> 
                        </div>
                        <div class="form-group">
                            <label class="col-label-sm">Apellido:</label>
                            <input type="text" class="form-control form-control-sm" name="apellido" placeholder="Apellido" pattern="[A-Za-z]{1,50}"/> 
                        </div>
                        <div class="form-group">
                            <label class="col-label-sm">Edad:</label>
                            <input type="number" class="form-control form-control-sm" name="edad" value="0"/> 
                        </div>
                        <div class="text-right ">
                            <input type="submit" class="btn btn-primary" name="registrar" value="Registrar" />
                        </div>
                    </div>
                </div>
            </form> 
        </div>
    </div>
</div>
@endsection