<?php

use Illuminate\Database\Seeder;

class PersonaTableSeeder extends Seeder {

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run() {
        DB::table('persona')->insert([
            'DNI' => '05679842Q',
            'nombre' => 'Juan',
            'apellido' => 'Flores',
            'edad' => 11,
        ]);
        DB::table('persona')->insert([
            'DNI' => Str::random(10),
            'nombre' => Str::random(10),
            'apellido' => Str::random(10),
            'edad' => 5,
        ]);
    }
    
/**
     * Run the database seeds.
     *
     * @return void
     */
    public static function run1($dni,$nombre,$apellido,$edad) {
        DB::table('persona')->insert([
            'DNI' => $dni,
            'nombre' => $nombre,
            'apellido' => $apellido,
            'edad' => $edad,
        ]);
    }
}
