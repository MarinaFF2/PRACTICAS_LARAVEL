<?php $__env->startSection('contenido'); ?>
<?php if($n == 0): ?>
<h2 class="text-center">Gestión de alquiler</h2>
<form action="gestionarAlquiler" method="POST">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <labe>DNI:</labe><input type="text" class="form-control form-control-sm form-control-md form-control-lg" name="dni" value=""/>
    </div>
    <div class="form-group">               
        <input type="submit" name="verReservas" value="Ver Reservas"/>
    </div>
    <div class="form-group">               
        <input type="submit" name="añadirReserva" value="Añadir Reserva"/>
    </div>
</form>
<?php elseif($n ==1): ?>
<div class="table-responsive ">
    <table class="table table-striped table-hover table-bordered">
        <caption>Coches reservados</caption>
        <thead class="thead-dark">
            <tr>
                <th>NOMBRE</th>
                <th>DNI</th>
                <th>MATRICULA</th>
                <th>MARCA</th>
                <th>MODELO</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($lr as $key) {
                ?>
            <form class="form-inline" action="gestionarAlquiler" method="POST">
                <?php echo e(csrf_field()); ?>

                <tr>
                    <td><?php echo $key['Nombre']; ?></td>
                    <td>
                        <?php echo $key['Dni']; ?> 
                        <input type="hidden" name="dni" value="<?php echo $key['Dni']; ?>"/>
                    </td>
                    <td>
                        <?php echo $key['Matricula']; ?>
                        <input type="hidden" name="id" value="<?php echo $key['idPropiedad']; ?>"/>
                   </td>
                    <td><?php echo $key['Marca']; ?></td>
                    <td><?php echo $key['Modelo']; ?></td>
                    <td>
                        <input type="submit" id="eliminar" name="botQuitarReserva" value="Quitar Reserva"/>
                    </td>
                </tr>
            </form>

            <?php
        }
        ?>
        </tbody>
    </table>
</div>
<?php elseif($n ==2): ?>
<div class="table-responsive">
    <table class="table table-striped table-hover table-bordered">
        <caption>Coches libres para reservar</caption>
        <thead class="thead-dark">
            <tr>
                <th>DNI</th>
                <th>MATRICULA</th>
                <th>MARCA</th>
                <th>MODELO</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($lr as $key) {
                ?>
            <form class="form-inline" action="gestionarAlquiler" method="POST">
                <?php echo e(csrf_field()); ?>

                <tr>
                    <td><input type="text" class="form-control form-control-sm form-control-md form-control-lg" name="dni" value="" pattern="[A-Z0-9]{1,50}"/></td>
                    <td><input type="text" class="form-control form-control-sm form-control-md form-control-lg" name="matricula" value="<?php echo $key->Matricula; ?>" readonly/></td>
                    <td><input type="text" class="form-control form-control-sm form-control-md form-control-lg" name="marca" value="<?php echo $key->Marca; ?>" readonly/></td>
                    <td><input type="text" class="form-control form-control-sm form-control-md form-control-lg" name="modelo" value="<?php echo $key->Modelo; ?>" readonly/></td>
                    <td>
                        <input type="submit"  name="botReservar" value="Reservar"/>
                    </td>
                </tr>
            </form>
            <?php
        }
        ?>
        </tbody>
    </table>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('maestraGestor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/alquilerCoche/resources/views/gestionarAlquiler.blade.php ENDPATH**/ ?>