<?php $__env->startSection('contenido'); ?> 
<header>
    <h1>Menu gestor</h1>
</header>
<main>                      
    <form name="menugestor" action="menugestor" method="POST">
        <?php echo e(csrf_field()); ?>                
        <input type="submit" class="btn btn-primary" name="altaUsuarios" value="Alta Usuarios">
        <input type="submit" class="btn btn-primary" name="altaCoches" value="Alta Coches">
        <input type="submit" class="btn btn-primary" name="gestionarAlquiler" value="Gestionar Alquiler">
        </div>
    </form>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('maestraGestor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/alquilerCoche/resources/views/menuGestor.blade.php ENDPATH**/ ?>