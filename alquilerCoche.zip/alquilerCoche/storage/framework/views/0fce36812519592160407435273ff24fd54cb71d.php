<?php $__env->startSection('contenido'); ?> 
<header>
    <h1>Menu Administrador</h1>
</header>
<main>                      
    <form name="menuadmin" action="menuadmin" method="POST">
        <?php echo e(csrf_field()); ?>                
        <input type="submit" class="btn btn-primary" name="crudUsuarios" value="Gestion Usuarios">
        <input type="submit" class="btn btn-primary" name="crudCoches" value="Gestion Coches">
        </div>
    </form>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('maestraAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\laravel\alquilerCoche\resources\views/menuAdministrador.blade.php ENDPATH**/ ?>