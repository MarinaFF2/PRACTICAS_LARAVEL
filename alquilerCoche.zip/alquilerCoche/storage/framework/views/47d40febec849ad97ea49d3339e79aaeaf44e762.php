<?php $__env->startSection('contenido'); ?> 
<h2 class="text-center">Gestión alta de usuarios</h2>
<form action="altaUsuarios" method="POST">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <labe>DNI:</labe><input type="text"  class="form-control form-control-sm form-control-md form-control-lg" name="dni" value="" pattern="[A-Z1-0]{2,5}"/>
    </div>
    <div class="form-group">
        <label>Correo:</label>
        <input type="email"  class="form-control form-control-sm form-control-md form-control-lg" name="correo" value=""/>
    </div>
    <div class="form-group">
        <label>Contraseña: (si eres usuario normal no hace falta)</label>
        <input type="password"  class="form-control form-control-sm form-control-md form-control-lg" name="pwd" value=""/>
    </div>
    <div class="form-group">
        <label>Confirmar contraseña: (si eres usuario normal no hace falta)</label>
        <input type="password"  class="form-control form-control-sm form-control-md form-control-lg" name="repwd" value=""/>
    </div>
    <div class="form-group">
        <label>Telefono:</label>
        <input type="text"  class="form-control form-control-sm form-control-md form-control-lg" name="tel" value="" pattern="[1-0]{1,50}"/>
    </div>
    <div class="form-group">
        <label>Nombre:</label>                
        <input type="text"  class="form-control form-control-sm form-control-md form-control-lg" name="nombre" value="" pattern="[A-Za-z]{1,50}"/>
    </div>
    <div class="form-group">
        <label>Elige un rol:</label>
        <label>Gestor</label><input type="radio" name="rol" value="Gestor"/>
        <label>Administrador</label><input type="radio" name="rol" value="Administrador"/>
        <label>Usuario</label><input type="radio" name="rol" value="Usuario"/>
    </div>
    <div class="form-group">
        <label>Edad:</label>              
        <input type="number"  class="form-control form-control-sm form-control-md form-control-lg" name="edad" value="0"/>
    </div>
    <div class="form-group">
        <input type="submit" name="botAltaUsuarios" value="Guardar"/>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('maestraGestor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/alquilerCoche/resources/views/altaUsuarios.blade.php ENDPATH**/ ?>