-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 20, 2020 at 12:11 PM
-- Server version: 5.7.28-0ubuntu0.18.04.4
-- PHP Version: 7.2.24-0ubuntu0.18.04.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alquilerCoche`
--

-- --------------------------------------------------------

--
-- Table structure for table `asignarroles`
--

CREATE TABLE `asignarroles` (
  `idRol` int(11) NOT NULL,
  `dni` varchar(10) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `asignarroles`
--

INSERT INTO `asignarroles` (`idRol`, `dni`, `id`) VALUES
(2, '2B', 2),
(1, '3C', 3),
(2, '4D', 4),
(1, '5E', 5),
(1, '6F', 6),
(0, ' 7G', 7),
(0, '1C', 9),
(0, '1F', 11),
(1, '1A', 12),
(0, '2Q', 13),
(0, '1B', 14);

-- --------------------------------------------------------

--
-- Table structure for table `coches`
--

CREATE TABLE `coches` (
  `Matricula` varchar(10) NOT NULL,
  `Marca` varchar(20) NOT NULL,
  `Modelo` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coches`
--

INSERT INTO `coches` (`Matricula`, `Marca`, `Modelo`) VALUES
('100A', 'Citroen', 'C3'),
('200B', 'Citroen', 'C5'),
('300C', 'Peugeot', '205'),
('400D', 'Peugeot', '405'),
('500E', 'Renault', 'Megane'),
('600F', 'Renault', 'Laguna');

-- --------------------------------------------------------

--
-- Table structure for table `personas`
--

CREATE TABLE `personas` (
  `DNI` varchar(10) NOT NULL,
  `Nombre` varchar(20) NOT NULL,
  `Tfno` varchar(20) NOT NULL,
  `edad` int(11) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `pwd` varchar(5000) NOT NULL,
  `activo` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `personas`
--

INSERT INTO `personas` (`DNI`, `Nombre`, `Tfno`, `edad`, `correo`, `pwd`, `activo`) VALUES
('1A', 'Carlos', '1', 9, 'c@c.c', 'c4ca4238a0b923820dcc509a6f75849b', 1),
('1B', 'qq', '12', 2, 'q@q.q', 'd41d8cd98f00b204e9800998ecf8427e', 0),
('1C', 'caca', '123234', 123, 'ca@ca', 'd41d8cd98f00b204e9800998ecf8427e', 0),
('1F', 'qwe', '12', 1, 'f@f.f', 'c4ca4238a0b923820dcc509a6f75849b', 0),
('2B', 'Laura', '2', 17, 'l@l.l', 'c4ca4238a0b923820dcc509a6f75849b', 1),
('2Q', 'wqe', '124', 1, 'w@w.w', 'd41d8cd98f00b204e9800998ecf8427e', 0),
('3C', 'Nathan', '3', 27, 'n@n.n', 'c4ca4238a0b923820dcc509a6f75849b', 1),
('4D', 'Marina', '4', 9, 'm@m.m', 'c4ca4238a0b923820dcc509a6f75849b', 1),
('5E', 'Isabel', '5', 25, 'i@i.i', 'c4ca4238a0b923820dcc509a6f75849b', 1),
('6F', 'Rafa', '6', 12, 'r@r.r', 'c4ca4238a0b923820dcc509a6f75849b', 1),
('7G', 'Victor', '7', 36, 'v@v.v', 'c4ca4238a0b923820dcc509a6f75849b', 0);

-- --------------------------------------------------------

--
-- Table structure for table `propiedades`
--

CREATE TABLE `propiedades` (
  `DNI` varchar(10) NOT NULL,
  `Matricula` varchar(10) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `propiedades`
--

INSERT INTO `propiedades` (`DNI`, `Matricula`, `id`) VALUES
('1A', '100A', 1),
('1A', '200B', 2),
('2B', '300C', 3),
('3C', '400D', 4);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `idRol` int(11) NOT NULL,
  `descripcion` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`idRol`, `descripcion`) VALUES
(0, 'Usuario'),
(1, 'Gestor de alquileres'),
(2, 'Administrador');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `asignarroles`
--
ALTER TABLE `asignarroles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coches`
--
ALTER TABLE `coches`
  ADD PRIMARY KEY (`Matricula`);

--
-- Indexes for table `personas`
--
ALTER TABLE `personas`
  ADD PRIMARY KEY (`DNI`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- Indexes for table `propiedades`
--
ALTER TABLE `propiedades`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `asignarroles`
--
ALTER TABLE `asignarroles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `propiedades`
--
ALTER TABLE `propiedades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
