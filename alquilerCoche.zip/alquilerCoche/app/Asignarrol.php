<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Asignarrol extends Model {

    protected $table = 'asignarroles'; //Por defecto tomaría la tabla 'personas'.
    public $timestamps = false;   //Con esto Eloquent no maneja automáticamente created_at ni updated_at.

}
