<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Propiedad extends Model {

    protected $table = 'propiedades'; //Por defecto tomaría la tabla 'personas'.
    public $timestamps = false;   //Con esto Eloquent no maneja automáticamente created_at ni updated_at.

}
