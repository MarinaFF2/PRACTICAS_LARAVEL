<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Persona;
use App\Coche;
use App\Propiedad;
use App\Auxiliar\Conexion;

class micontrolador extends Controller {

    public function cerrarSesion(Request $req) {
        session()->invalidate();
        session()->regenerate();
        return view('inicioSesion');
    }

    public function inicioSesion(Request $req) {
        $correo = $req->get('usuario');
        $pass = $req->get('pwd');
        $passHash = md5($pass);
        $n = [];
        $n = Conexion::existeUsuario($correo, $passHash);        
//        $n = Conexion::existeUsuario($correo, $pass);

        if ($n != null) {
            session()->put('usu', $n);
            foreach ($n as $u) {
                $rol = $u['rol'];
            }
            if ($rol == 1) {
                echo '<div class="alert alert-primary alert-dismissible fade show" role="alert">
                    Has inicado sesion como gestor
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
                return view('menuGestor');
            } else if ($rol == 2) {
                echo '<div class="alert alert-primary alert-dismissible fade show" role="alert">
                    Has inicado sesion como administrador
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
                return view('menuAdministrador');
            } else {
                echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Error al introducir los datos vuelve a intentarlo.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
                return view('inicioSesion');
            }
        } else {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Error al introducir los datos vuelve a intentarlo.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
            return view('inicioSesion');
        }
    }

    public function menuadmin(Request $req) {
        if (isset($_REQUEST['crudUsuarios'])) {
            $lu = [];
            $lu = Conexion::obtenerUsuarios();
            return view('crudUsuarios', ['lu' => $lu]);
        }
        if (isset($_REQUEST['crudCoches'])) {
            $lc = [];
            $lc = Conexion::obtenerCoches();
            return view('crudCoches', ['lc' => $lc]);
        }
    }

    public function menugestor(Request $req) {
        if (isset($_REQUEST['altaUsuarios'])) {
            return view('altaUsuarios');
        }
        if (isset($_REQUEST['altaCoches'])) {
            return view('altaCoches');
        }
        if (isset($_REQUEST['gestionarAlquiler'])) {
            $w = ['n' => 0];
            return view('gestionarAlquiler', $w);
        }
    }

    public function gestionarAlquiler(Request $req) {
        //para ver tus reservas
        //muestra tabla
        if (isset($_REQUEST['verReservas'])) {
            $dni = $req->get('dni');
            $lr = [];
            $lr = Conexion::obtenerReservaCoches($dni);
            $w = ['n' => 1,
                'lr' => $lr
            ];
            return view('gestionarAlquiler', $w);
        }
        //para añadir resrvas de coches libres
        //muestra tabla
        if (isset($_REQUEST['añadirReserva'])) {
            $lr = [];
            $lr = Conexion::obtenerCochesSinReservar();
            $w = ['n' => 2,
                'lr' => $lr
            ];
            return view('gestionarAlquiler', $w);
        }
        //reservamos coche
        if (isset($_REQUEST['botReservar'])) {
            $dni = $req->get('dni');
            $matricula = $req->get('matricula');
            Conexion::insertarReservar($dni, $matricula);
            $w = ['n' => 0];
            return view('gestionarAlquiler', $w);
        }
        //quitamos reserva del coche
        if (isset($_REQUEST['botQuitarReserva'])) {
            $id = $req->get('id');
            Conexion::borrarReserva($id);
            $w = ['n' => 0];
            return view('gestionarAlquiler', $w);
        }
    }

    //Controlador de alta de coches
    public function altaCoches(Request $req) {
        $matricula = $req->get('Matricula');
        $marca = $req->get('Marca');
        $modelo = $req->get('Modelo');
        Conexion::insertarCoche($matricula, $marca, $modelo);
        return view('altaCoches');
    }

    //Controlador de alta de usuarios
    public function altaUsuarios(Request $req) {
        if (isset($_REQUEST['botAltaUsuarios'])) {
            $dni = $req->get('dni');
            $correo = $req->get('correo');
            $r = $req->get('rol');
            if (strcmp($r, 'Gestor')) {
                $rol = 1;
            } else if (strcmp($r, 'Administrador')) {
                $rol = 2;
            } else if (strcmp($r, 'Usuario')) {
                $rol = 0;
            }
            if ($req->get('pwd') != null && $req->get('repwd') != null) {
                $pwd = $req->get('pwd');
                $repwd = $req->get('repwd');
                if ($pwd == $repwd) {
                    $passHash = md5($pwd);
                    $tel = $req->get('tel');
                    $nombre = $req->get('nombre');
                    $edad = $req->get('edad');
                    Conexion::insertarUsuarios($correo, $dni, $passHash, $nombre, $tel, $edad,1);
                    Conexion::insertarRol($dni, $rol);
                } else {
                    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Clave duplicada.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
                }
            } else {
                $pwd = '';
                $passHash = md5($pwd);
                $tel = $req->get('tel');
                $nombre = $req->get('nombre');
                $edad = $req->get('edad');
                Conexion::insertarUsuarios($correo, $dni, $passHash, $nombre, $tel, $edad,0);
                Conexion::insertarRol($dni, $rol);
            }
            return view('altaUsuarios');
        }
    }

    //Controlador del crud de usuarios
    public function crudUsuarios(Request $req) {
        if ($req->get('botUsuario') == 'Editar') {
            $dni = $req->get('dni');
            $correo = $req->get('correo');
            $tf = $req->get('tel');
            $nombre = $req->get('nombre');
            $edad = $req->get('edad');
            if ($req->get('activo') == 'checked') {
                $activo = 1;
            } else {
                $activo = 0;
            }
            Conexion::ModificarUsuarios($dni,$correo, $nombre, $tf, $edad, $activo);
            if ($req->get('rol') == 'Gestor') {
                Conexion::ModificarRol(1, $dni);
            }
            if ($req->get('rol') == 'Administrador') {
                Conexion::ModificarRol(2, $dni);
            }
            if ($req->get('rol') == 'Usuario') {
                Conexion::ModificarRol(0, $dni);
            }
            $lu = [];
            $lu = Conexion::obtenerUsuarios();
            return view('crudUsuarios', ['lu' => $lu]);
        }

        //Cuando eliminas a un usuario
        if ($req->get('botUsuario') == 'X') {
            $dni = $req->get('dni');
            Conexion::borrarUsuario($dni);
            Conexion::borrarRol($dni);
            $lu = [];
            $lu = Conexion::obtenerUsuarios();
            return view('crudUsuarios', ['lu' => $lu]);
        }
    }

    //Controlador del crud de coches
    public function crudCoches(Request $req) {
        if (isset($_REQUEST['botCoche'])) {
            //cuando editas a un usuario
            if ($req->get('botCoche') == 'Editar') {
                $matricula = $req->get('matricula');
                $marca = $req->get('marca');
                $modelo = $req->get('modelo');
                Conexion::ModificarCoche($matricula, $marca, $modelo);
                $lc = [];
                $lc = Conexion::obtenerCoches();
                return view('crudCoches', ['lc' => $lc]);
            }

            //Cuando eliminas a un usuario
            if ($req->get('botCoche') == 'X') {
                $matricula = $req->get('matricula');
                Conexion::borrarCoche($matricula);
                $lc = [];
                $lc = Conexion::obtenerCoches();
                return view('crudCoches', ['lc' => $lc]);
            }
        }
    }

}
