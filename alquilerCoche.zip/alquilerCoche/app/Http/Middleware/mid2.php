<?php

namespace App\Http\Middleware;

use Closure;

class mid2 {

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next) {
        $n = session()->get('usu');
        //comprobar si eres gestor
        foreach ($n as $u) {
            $rol = $u['rol'];
        }
        if ($rol == 1) {
            return $next($request);
        } else {
            abort(503);
            //return view('errors/518');
        }
    }

}
