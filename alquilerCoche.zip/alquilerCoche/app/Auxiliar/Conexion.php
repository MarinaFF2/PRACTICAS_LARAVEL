<?php

namespace App\Auxiliar;

use App\Persona;
use App\Propiedad;
use App\Coche;
use App\Asignarrol;

/**
 * Description of Conexion
 *
 * @author daw207
 */
class Conexion {

    /**
     * 
     * @param type $correo
     * @param type $pwd
     * @return type
     */
    static function existeUsuario($correo, $pwd) {
        $ar = Asignarrol::all();
        $v = [];
        foreach ($ar as $a) {
            $p = Persona::where('correo', $correo)->where('pwd', $pwd)->where('activo', '1')->where('DNI', $a->dni)->first(); //aqui se cruzan
            if ($p) {
                $v[] = ['DNI' => $p->DNI,
                    'correo' => $p->correo,
                    'nombre' => $p->Nombre,
                    'tel' => $p->Tfno,
                    'rol' => $a->idRol,
                    'edad' => $p->edad,
                    'activo' => $p->activo];
            }
        }
        return $v;
    }

    /**
     * 
     * @param type $correo
     * @return type
     */
    static function existeUsu($correo) {
        $ar = Asignarrol::all();
        $v = [];
        foreach ($ar as $a) {
            $p = Persona::where('correo', $correo)->where('activo', 1)->where('DNI', $a->dni)->first(); //aqui se cruzan
            if ($p) {
                $v[] = ['DNI' => $p->DNI,
                    'correo' => $p->correo,
                    'nombre' => $p->Nombre,
                    'tel' => $p->Tfno,
                    'rol' => $a->idRol,
                    'edad' => $p->edad,
                    'activo' => $p->activo];
            }
        }
        return $v;
    }

    /**
     * 
     * @return type
     */
    static function obtenerUsuarios() {
        $ar = Asignarrol::all();
        $v = [];
        foreach ($ar as $a) {
            $w = Persona::where('DNI', $a->dni)->get(); //aqui se cruzan
            foreach ($w as $p) {
                $v [] = ['DNI' => $p->DNI,
                    'correo' => $p->correo,
                    'Nombre' => $p->Nombre,
                    'Tfno' => $p->Tfno,
                    'idRol' => $a->idRol,
                    'edad' => $p->edad,
                    'activo' => $p->activo];
            }
        }
        return $v;
    }

    /**
     * insertar usuario
     * @param type $correo
     * @param type $dni
     * @param type $pwd
     * @param type $nombre
     * @param type $tf
     * @param type $edad
     * @return string
     */
    static function insertarUsuarios($correo, $dni, $pwd, $nombre, $tf, $edad,$activo) {
        $pe = new Persona;
        $pe->correo = $correo;
        $pe->DNI = $dni;
        $pe->pwd = $pwd;
        $pe->Nombre = $nombre;
        $pe->Tfno = $tf;
        $pe->edad = $edad;
        $pe->activo = $activo;
        try {
            $pe->save(); //aqui se hace la insercion   
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    Insertado con exito.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        } catch (\Exception $e) {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Clave duplicada.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        }
    }

    /**
     * MODIFICAR USUARIO
     * @param type $correo
     * @param type $nombre
     * @param type $tf
     * @param type $edad
     * @param type $activo
     */
    static function ModificarUsuarios($dni, $correo, $nombre, $tf, $edad, $activo) {
        try {
            $p = Persona::where('correo', $correo)
                ->where('DNI', $dni)
                ->update(['Nombre' => $nombre,
            'Tfno' => $tf,
            'edad' => $edad,
            'activo' => $activo]);
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    Modificado con exito usuario.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        } catch (\Exception $e) {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Error al modificar usuario.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        }
    }

    /**
     * METODO MODIFICAR USUARIO
     * @param type $correo
     * @param type $pwd
     */
    static function ModificarUsuContra($correo, $pwd) {
        $p = Persona::where('correo', $correo)->first();
        try {
            $p->pwd = $pwd;
            $p->save();
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    Modificado con exito.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        } catch (\Exception $e) {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Error al modificar.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        }
    }

    /**
     * BORRAR USUARIO   
     * @param type $dni
     */
    static function borrarUsuario($dni) {
//        dd($correo);    
        try {
            Persona::where('correo', $dni)->delete();
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    Borrado con exito.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        } catch (\Exception $e) {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Error al borrar.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        }
    }

    /**
     * CLASE ROL
     */

    /**
     * METODO INSERTAR ROL
     * @param type $dni
     * @param type $rol
     */
    static function insertarRol($dni, $rol) {
        $a = new Asignarrol;
        $a->id = 0;
        $a->dni = $dni;
        $a->idRol = $rol;
        try {
            $a->save(); //aqui se hace la insercion
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    Se ha insertado bien
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        } catch (\Exception $e) {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Clave duplicada.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        }
    }

    /**
     * modificar rol
     * @param type $rol
     * @param type $dni
     */
    static function ModificarRol($rol, $dni) {
        $a = Asignarrol::where('dni', $dni)->first();
        try {
            $a->idRol = $rol;
            $a->save();
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    Modificado rol con exito.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        } catch (\Exception $e) {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Error al modificar rol.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        }
    }

    /**
     * BORRAR ROL
     * @param type $dni
     */
    static function borrarRol($dni) {
        try {
            Asignarrol::find($dni)->delete();
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    Borrado con exito.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        } catch (\Exception $e) {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Error al borrar.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        }
    }

    /**
     * clase coche
     */

    /**
     * 
     * @param type $matricula
     * @return type
     */
    static function existeCoche($matricula) {
        $v = [];
        $c = Coche::where('Matricula', $matricula)->first(); //aqui se cruzan
        if ($c) {
            $v[] = ['matricula' => $c->Matricula,
                'marca' => $c->Marca,
                'modelo' => $c->Modelo];
        }
        return $v;
    }

    /**
     * 
     * @return type
     */
    static function obtenerCoches() {
        $w = Coche::all();
        return $w;
    }

    /**
     * 
     * @param type $matricula
     * @param type $marca
     * @param type $modelo
     * @return string
     */
    static function insertarCoche($matricula, $marca, $modelo) {
        $c = new Coche;
        $c->Matricula = $matricula;
        $c->Marca = $marca;
        $c->Modelo = $modelo;
        try {
            $c->save(); //aqui se hace la insercion
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    Se ha insertado bien
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        } catch (\Exception $e) {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Clave duplicada.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        }
    }

    /**
     * @param type $matricula
     * @param type $marca
     * @param type $modelo
     */
    static function ModificarCoche($matricula, $marca, $modelo) {
        $c = Coche::where('Matricula', $matricula)->first();
        try {
            $c->Marca = $marca;
            $c->Modelo = $modelo;
            $c->save();
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    Modificado con exito.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        } catch (\Exception $e) {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Error al modificar.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        }
    }

    /**
     * BORRAR coche  
     * @param type $matricula
     */
    static function borrarCoche($matricula) {
        $c = Coche::where('Matricula', $matricula)->first();
        try {
            $c->delete();
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    Borrado con exito.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        } catch (\Exception $e) {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Error al borrar.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        }
    }

    /**
     * 
     * @return type
     */
    static function obtenerCochesSinReservar() {
        $v = \DB::select("SELECT * FROM coches c WHERE c.Matricula not in (select Matricula from propiedades);");
//        $m = [];
//        $w = Propiedad::all();
//        foreach ($w as $a) {
//            $m = [$a->Matricula];
//        }
//        $q = Coche::whereNotIn('Matricula', $m)->get();
//        foreach ($q as $c) {
//            $v [] = ['Matricula' => $c->Matricula,
//                'Marca' => $c->Marca,
//                'Modelo' => $c->Modelo];
//        }
        return $v;
    }

    /**
     * 
     * @return type
     */
    static function obtenerReservaCoches($dni) {
        $v = [];
        $a = Persona::where('DNI', $dni)->first();
        $w = Propiedad::where('DNI', $dni)->get();
        foreach ($w as $p) {
            $q = Coche::where('Matricula', $p->Matricula)->get();
            foreach ($q as $c) {
                $v [] = ['Dni' => $a->DNI,
                    'Nombre' => $a->Nombre,
                    'Matricula' => $p->Matricula,
                    'Marca' => $c->Marca,
                    'Modelo' => $c->Modelo,
                    'idPropiedad' => $p->id];
            }
        }
        return $v;
    }

    /**
     * 
     * @return type
     */
    static function ModificarReservar($id, $matricula, $dni) {
        $c = Propiedad::find($id);
        try {
            $c->Matricula = $matricula;
            $c->DNI = $dni;
            $c->save();
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    Modificado con exito.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        } catch (\Exception $e) {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Error al modificar.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        }
    }

    /**
     * 
     * @return type
     */
    static function insertarReservar($dni, $matricula) {
        $c = new Propiedad;
        $c->Matricula = $matricula;
        $c->DNI = $dni;
        $c->id = 0;
        try {
            $c->save(); //aqui se hace la insercion
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    Se ha insertado bien
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        } catch (\Exception $e) {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Clave duplicada.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        }
    }

    /**
     * BORRAR coche  
     * @param type $id
     */
    static function borrarReserva($id) {
        $c = Propiedad::where('id', $id)->first();
        try {
            $c->delete();
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    Borrado con exito.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        } catch (\Exception $e) {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Error al borrar.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">X</span>
                    </button>
                  </div>';
        }
    }

}
