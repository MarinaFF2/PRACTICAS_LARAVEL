<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */

use App\Auxiliar\Conexion;

Route::get('/', function () {
    return view('inicioSesion');
});

Route::post('inicioSesion', 'miControlador@inicioSesion');
Route::post('cerrarSesion', 'miControlador@cerrarSesion');
Route::group(['middleware' => ['mid3']], function() {
    Route::get('inicioSesion', 'miControlador@inicioSesion');
    Route::get('cerrarSesion', 'miControlador@cerrarSesion');
});

//gestor
Route::group(['middleware' => ['mid2']], function() {
    Route::post('menugestor', 'miControlador@menugestor');
    Route::get('menugestor', function () {
        return view('menuGestor');
    });
    Route::post('altaUsuarios', 'miControlador@altaUsuarios');
    Route::get('altaUsuarios', function () {
        return view('altaUsuarios');
    });
    Route::post('altaCoches', 'miControlador@altaCoches');
    Route::get('altaCoches', function () {
        return view('altaCoches');
    });
    Route::post('gestionarAlquiler', 'miControlador@gestionarAlquiler');
    Route::get('gestionarAlquiler', function () {
        return view('gestionarAlquiler', ['n' => 0]);
    });
});

//admin
Route::group(['middleware' => ['mid1']], function() {
    Route::post('menuadmin', 'miControlador@menuadmin');
    Route::get('menuadmin', function () {
        return view('menuAdministrador');
    });
    Route::post('crudUsuarios', 'miControlador@crudUsuarios');
    Route::get('crudUsuarios', function () {
        $lu = [];
        $lu = Conexion::obtenerUsuarios();
        return view('crudUsuarios', ['lu' => $lu]);
    });
    Route::post('crudCoches', 'miControlador@crudCoches');
    Route::get('crudCoches', function () {
        $lc = [];
        $lc = Conexion::obtenerCoches();
        return view('crudCoches', ['lc' => $lc]);
    });
});
