@extends('maestraAdmin')
@section('contenido') 
<header>
    <h1>Menu Administrador</h1>
</header>
<main>                      
    <form name="menuadmin" action="menuadmin" method="POST">
        {{ csrf_field() }}                
        <input type="submit" class="btn btn-primary" name="crudUsuarios" value="Gestion Usuarios">
        <input type="submit" class="btn btn-primary" name="crudCoches" value="Gestion Coches">
        </div>
    </form>
</main>
@endsection
