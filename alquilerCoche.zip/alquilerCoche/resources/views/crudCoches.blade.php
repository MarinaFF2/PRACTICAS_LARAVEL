@extends('maestraAdmin')
@section('contenido') 
<h2 class="text-center">Gestión de coches</h2>
<div class="table-responsive">
    <table class="table table-striped table-hover table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>MATRICULA</th>
                <th>MARCA</th>
                <th>MODELO</th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($lc as $key) {
                ?>
            <form class="form-inline" action="crudCoches" method="POST">
                {{ csrf_field() }}
                <tr>
                    <td><input type="text" class="in" class="form-control form-control-sm form-control-md form-control-lg" name="matricula" value="<?php echo $key->Matricula; ?>" readonly/></td>
                    <td><input type="text" class="in" class="form-control form-control-sm form-control-md form-control-lg" name="marca" value="<?php echo $key->Marca; ?>" pattern="[A-Za-z]{1,50}"/></td>
                    <td><input type="text" class="in" class="form-control form-control-sm form-control-md form-control-lg" name="modelo" value="<?php echo $key->Modelo; ?>"/></td>

                    <td>
                        <input type="submit" id="eliminar" name="botCoche" value="X"/>
                    </td>
                    <td>
                        <input type="submit" id="editar" name="botCoche" value="Editar"/>
                    </td>
    <!--                                        <td><button type="submit" id="editar" class="btn" name="editar" /></td>
                                    <td><button type="submit" id="eliminar" class="btn" name="eliminar" /></td>-->
                </tr>
            </form>
            <?php
        }
        ?>
        </tbody>
    </table>
</div>
@endsection
