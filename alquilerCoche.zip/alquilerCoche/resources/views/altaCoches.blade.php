@extends('maestraGestor')
@section('contenido') 
<h2 class="text-center">Gestión alta de coches</h2>
<form action="altaCoches" method="POST">
    {{ csrf_field() }}
    <div class="form-group">
        <labe>Matricula:</labe>
        <input type="text"  class="form-control form-control-sm form-control-md form-control-lg" name="Matricula" value=""/>
    </div>
    <div class="form-group">
        <label>Marca:</label>
        <input type="text"  class="form-control form-control-sm form-control-md form-control-lg" name="Marca" value=""/>
    </div>
    <div class="form-group">
        <label>Modelo:</label>
        <input type="text"  class="form-control form-control-sm form-control-md form-control-lg" name="Modelo" value=""/>
    </div>    
    <div class="form-group">
        <input type="submit" name="botAltaUsuarios" value="Guardar"/>
    </div>
</form>
@endsection
