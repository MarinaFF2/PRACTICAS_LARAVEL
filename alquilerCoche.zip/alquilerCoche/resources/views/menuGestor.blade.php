@extends('maestraGestor')
@section('contenido') 
<header>
    <h1>Menu gestor</h1>
</header>
<main>                      
    <form name="menugestor" action="menugestor" method="POST">
        {{ csrf_field() }}                
        <input type="submit" class="btn btn-primary" name="altaUsuarios" value="Alta Usuarios">
        <input type="submit" class="btn btn-primary" name="altaCoches" value="Alta Coches">
        <input type="submit" class="btn btn-primary" name="gestionarAlquiler" value="Gestionar Alquiler">
        </div>
    </form>
</main>
@endsection
