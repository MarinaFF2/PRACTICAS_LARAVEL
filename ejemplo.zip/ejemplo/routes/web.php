<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*
* Route::post -> llegaremos validando un formulario*
* Route::get -> llegaremos navegando o por enlace
*/

//Route::get('/', function () {
//    return view('welcome');
//});

Route::get('/','micontrolador@indice');
Route::post('validar','micontrolador@valida');
//Route::get('/', function () {
//    return view('indice');
//});

//redirige al controlador
Route::get('otraruta','micontrolador@indice');


//Route::get('otraruta', function () {
//    return view('welcome');
//});
Route::get('enlace', function () {
    return view('vista');
});
