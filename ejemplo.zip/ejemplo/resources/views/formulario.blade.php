<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        
    </head>
    <body>
        <form action="validar" method="post" name="formu">
            <!--para que no salga pagina expirada-->
            {{ csrf_field() }}
            <input type="text" name="nombre" value="">
            <input type="number" name="edad" value="0">
            <input type="submit" name="aceptar" value="Aceptar">
        </form>
    </body>
</html>
