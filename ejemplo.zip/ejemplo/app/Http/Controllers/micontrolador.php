<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class micontrolador extends Controller {

    public function indice() {
        return view('formulario');
    }

    //valida un formulario
    public function valida(Request $req) {
        $nombre = $req->get('nombre');
        $edad = $req->get('edad');

        //vector asociativo
        $datos = [
            'dato1' => $nombre,
            'dato2' => $edad
        ];
        //se lo pasamos a una vista
       return view('vista',$datos);
    }

    public function ruta() {
        
    }

}
