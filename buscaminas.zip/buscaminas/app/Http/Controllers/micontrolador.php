<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Clase\Modelo\Tablero;

class micontrolador extends Controller {

    public function indice() {
        return view('principal');
    }

    public function iniciarTablero(Request $req) {
        //cuando vienes del index
        if (null !== $req->get('jugar')) {
            $t = $req->get('t');
            $m = $req->get('m');
            $ta = new Tablero($t, $m);
            $s = $ta->comprobarTM();
            if ($s) {
                $vis = $ta->iniciarTableroVista(); //vector que se va a ver
                $ve = $ta->iniciarTablero(); //vector donde esta la solucion
                session()->put('t', $t);
                session()->put('m', $m);
                session()->put('tablero', $ve);
                session()->put('vista', $vis);
                session()->put('cont', 0);
//                $ta->mostrarTablero($vis);
                return view('tablero1');
            } else {
                return view('principal');
            }
        }
    }

    public function jugada1(Request $req) {
        $t = session()->get('t');
        $m = session()->get('m');
        $ta = new Tablero($t, $m);
        $ve = session()->get('tablero');
        $vis = session()->get('vista');

        if ($req->get('rendirse') == 'Rendirse') {
            $ve = session()->get('tablero');
            $vis = session()->get('vista');
            return view('rendirse');
        }

        if (null !== $req->get('boton')) {
            $pos = $req->get('boton');
            $nu = $ta->comprobarTablero($ve, $vis, $pos);
            session()->put('vista', $vis);
            switch ($nu){
                case 0:
                    return view('tablero2');
                    break;
                case 1:
                    return view('perdido');
                    break;
                case 2:
                    return view('ganado');
                    break;
            }
            
        }
    }

    public function jugada2(Request $req) {
        $t = session()->get('t');
        $m = session()->get('m');
        $ta = new Tablero($t, $m);
        $ve = session()->get('tablero');
        $vis = session()->get('vista');

        if ($req->get('rendirse') == 'Rendirse') {
            $ve = session()->get('tablero');
            $vis = session()->get('vista');
            return view('rendirse');
        }

        if (null !== $req->get('boton')) {
            $pos = $req->get('boton');
            $ta->comprobarTablero($ve, $vis, $pos);
            session()->put('vista', $vis);
        }
    }

    public function volver(Request $req) {
        if ($req['volver'] == 'Volver') {
            $ve = $req->get('tablero');
            $vis = $req->get('vista');
//            session()->flush();
            return view('principal');
        }
    }

}
