<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','micontrolador@indice');
Route::post('iniciar','micontrolador@iniciarTablero');
Route::post('jugada1','micontrolador@jugada1');
Route::post('jugada2','micontrolador@jugada2');
Route::get('enlace', 'micontrolador@indice');

/*
 * Cuando terminas de jugar
 */
Route::post('ganado','micontrolador@volver');
Route::post('perdido','micontrolador@volver');
Route::post('rendido','micontrolador@volver');
