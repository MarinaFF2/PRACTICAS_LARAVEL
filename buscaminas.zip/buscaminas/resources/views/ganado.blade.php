<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            .h{
                text-align: center;
                width: 30px;
            }
        </style>
    </head>
    <body>
        <?php
        use App\Clase\Modelo\Tablero;
        $v = session()->get('tablero');
        $t = session()->get('t');
        $m = session()->get('m');
        $ta = new Tablero($t,$m);
        ?>
        <form name="tablero" action="ganado" method="POST">  
            {{ csrf_field() }}
            <?php
            echo 'Has ganado.<br>';
            for ($i = 0; $i < count($v); $i++) {
               if ($v[$i] == 99) {
                    ?>
                    <input type="submit" class="h" name="h" value="<?php echo '*'; ?>" readonly> 
                    <?php
                } else {
                    ?>
                    <input type="submit" class="h" name="h" value="<?php echo $v[$i]; ?>" readonly> 
                    <?php
                }

            }
            ?>
                <br>
            <input type="submit" name="volver" value="Volver">
        </form> 
    </body>
</html>