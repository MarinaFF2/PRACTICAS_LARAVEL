<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            .h{
                text-align: center;
                width: 30px;
            }
        </style>
    </head>
    <body>
        <?php
        $v = session()->get('vista');
        $t = session()->get('t');
        $m = session()->get('m');
        $ta = new Tablero($t, $m);
        ?>
        <form name="tablero" action="jugada2" method="POST"> 
            {{ csrf_field() }}
            <?php
            for ($i = 0; $i < $t; $i++) {
                ?>
                <input type="submit" class="h" name='boton' value="<?php echo $i; ?>"> 
                <?php
            }
            ?>
            <br>
            <?php
            for ($i = 0; $i < count((array) $v); $i++) {
                if ($v[$i] == 99) {
                    ?>
                    <input type="submit" class="h" name="h" value="<?php echo '*'; ?>" readonly> 
                    <?php
                } else {
                    ?>
                    <input type="submit" class="h" name="h" value="<?php echo $v[$i]; ?>" readonly> 
                    <?php
                }
            }
            ?>
            <br>
            <input type="submit" name="volver" value="Volver">
            <input type="submit" name="rendirse" value="Rendirse"> 
        </form>
    </body>
</html>