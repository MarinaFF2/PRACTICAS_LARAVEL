<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            .h{
                text-align: center;
                width: 30px;
            }
        </style>
    </head>
    <body>
        <?php
        $v = session()->get('tablero');
        $t = session()->get('t');
        $m = session()->get('m');
        $ta = new Tablero($t, $m);
        ?>
        <form name="tablero" action="jugada1" method="POST"> 
            {{ csrf_field() }}
            <?php
            for ($i = 0; $i < $t; $i++) {
                ?>
                <input type="submit" class="h" name='boton' value="<?php echo $i; ?>"> 
                <?php
            }
             print_r($v);
            ?>
            <br>
            <input type="submit" name="volver" value="Volver">
            <input type="submit" name="rendirse" value="Rendirse"> 
        </form> 
    </body>
</html>