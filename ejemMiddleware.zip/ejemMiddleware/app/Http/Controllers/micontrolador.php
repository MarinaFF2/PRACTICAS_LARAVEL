<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class micontrolador extends Controller {

    public function valida(Request $request) {
        echo 'Has introducido: ' . $request->get('caja') . '<br>';
    }

    public function formul() {
        return view('formulario');
    }

}
