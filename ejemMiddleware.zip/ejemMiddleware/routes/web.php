<?php

/*

  Este ejemplo también contiene información de como incluir JS y CSS en Laravel.

 */


Route::get('/', function () {
    return view('welcome');
});


//a) Middleware en una función closure.
//Route::get('ejem', function () {
//    return view('formulario');
//})->middleware('mid1');
//b) Middleware a una ruta.
//Route::get('ejem', 'micontrolador@formul')->middleware('mid1');
//c) Varios middleware a varias rutas.
//Route::get('ejem', 'micontrolador@formul')->middleware(['mid1','mid2']->as('ejem');
//d) Nomenclatura completa.
//Route::get('ejem',[
//    'uses' => 'micontrolador@formul',
//    'as' => 'ejem',
//    'middleware' => 'mid1']);
//e) Nomenclatura completa varios middleware.
//Route::get('ejem',[
//    'uses' => 'micontrolador@formul',
//    'as' => 'ejem',
//    'middleware' => ['mid1','mid2']]);
//f) Grupo de rutas.
Route::group(['middleware' => ['mid1', 'mid2']], function() {

    Route::get('ejem', [
        'uses' => 'micontrolador@formul',
        'as' => 'ejem']);

    Route::get('ejem2', [
        'uses' => 'micontrolador@formul',
        'as' => 'ejem2']);
});



Route::post('validar', 'micontrolador@valida');
//Se protege la ruta post porque da error de laravel si se intenta acceder desde un get a una ruta post, asi no aparece el error
Route:get('validar','welcome');
