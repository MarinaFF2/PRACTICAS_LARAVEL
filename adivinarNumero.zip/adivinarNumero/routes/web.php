<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//al principio del todo, es como mi index
Route::get('/','micontrolador@indice');

//para validar el formulario de la pagina
Route::post('validar','micontrolador@valida');