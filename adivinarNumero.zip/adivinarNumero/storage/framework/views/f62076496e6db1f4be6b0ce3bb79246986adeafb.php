<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col">
                    <form name="formulario" class="form-inline" action="validar" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <p>Numero
                            <input type="text" name="numUsu" value="">
                            <br>
                            <input type="submit" name="aceptar" value="Aceptar">
                        </p>
                    </form>
                </div>
            </div>
        </div>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\html\laravel\adivinarNumero\resources\views/principal.blade.php ENDPATH**/ ?>