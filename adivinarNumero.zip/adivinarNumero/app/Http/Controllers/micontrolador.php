<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class micontrolador extends Controller {

    public function indice() {
        return view('principal');
    }

    public function valida(Request $req) {
        if ($req->get('numUsu') == NULL) {
            iniciar();
        } else {
            $numUsu = $req->get('numUsu');
            if ($numUsu != null) {
                $intentos = session()->get('intento');
                $numAdvi = session()->get('numAdvi');

                echo $numAdvi;

                if ($numUsu == $numAdvi) {
                    echo 'Intentos: ' . $intentos . '<br>' . '¡Has ganado!';
                } else if ($numUsu > $numAdvi) {
                    echo 'Intentos: ' . $intentos . '<br>' . 'Es menor que ' . $numUsu . '<br>';
                    $intentos++;
                    session()->put('intento', $intentos);
                } else {
                    echo 'Intentos: ' . $intentos . '<br>' . 'Es mayor que ' . $numUsu . '<br>';
                    $intentos++;
                    session()->put('intento', $intentos);
                }
                if ($intentos >= 5) {
                    echo '¡Has perdido!';
                }
            }
        }
        return view('principal');
    }

    public function iniciar() {
        session()->put('intento', 0);
        session()->put('numAdvi', round(rand(1, 10)));
        echo 'Primera vez';
    }

}
