<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col">
                    <form name="formulario" class="form-inline" action="validar" method="POST">
                        {{ csrf_field() }}
                        <p>Numero
                            <input type="text" name="numUsu" value="">
                            <br>
                            <input type="submit" name="aceptar" value="Aceptar">
                        </p>
                    </form>
                </div>
            </div>
        </div>

    </body>
</html>
