<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class miControlador extends Controller {

    public function indice() {
        $datos = [
            'texto' => 'Un texto de ejemplo',
            'num' => 36,
            'vector' => [1, 2, 3, 4]
        ];
        return view('esclava',$datos);
    }
    
    public function otro() {
        $datos = [
            'vector' => [1, 2, 3, 4]
        ];
        return view('esclava2',$datos);
    }

}
