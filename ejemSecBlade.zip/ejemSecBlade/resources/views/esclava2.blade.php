@extends('maestra')

@section('titulo')
Otra página.
@endsection

@section('contenido')
<H1>Esto es otra página que hereda el esqueleto.</H1>

Valor del vector:
@foreach($vector as $valor)
    {!! $valor !!}
@endforeach

@endsection



