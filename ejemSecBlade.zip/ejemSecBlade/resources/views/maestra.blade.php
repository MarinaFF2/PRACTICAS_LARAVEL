<!DOCTYPE html>
<html>
    <head>
        <title> @yield('titulo') </title>

    </head>
    <body>

        @yield('contenido')

        <footer>
            <p>©Copyleft.</p>
        </footer>
    </body>
</html>
