@extends('maestra')

@section('titulo')
Esto es una prueba de Blade y de secciones.
@endsection

@section('contenido')
Valor de la variable numérica: {!! $num !!}<br/>
Texto: {!! $texto !!}<br/>
<?php
echo 'Podemos intercalar blade con PHP estándar.' . '<br>';
?>

@if ($num > 0)
    <input type="text" name="caja" value="">
    <input type="submit" name="Aceptar" value="Aceptar">
    <br>
@else
    <p>Esto va en el else</p>
    <input type="text" name="else" value="else">
    <br>
@endif
Valor del vector:
@foreach($vector as $valor)
    {!! $valor !!}
@endforeach

@endsection



