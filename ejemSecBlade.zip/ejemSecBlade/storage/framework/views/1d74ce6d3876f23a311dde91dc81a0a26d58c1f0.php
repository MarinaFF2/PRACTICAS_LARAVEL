<?php $__env->startSection('titulo'); ?>
Otra página.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<H1>Esto es otra página que hereda el esqueleto.</H1>

Valor del vector:
<?php $__currentLoopData = $vector; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $valor; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('maestra', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>