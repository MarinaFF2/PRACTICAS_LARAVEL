<?php $__env->startSection('titulo'); ?>
Esto es una prueba de Blade y de secciones.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
Valor de la variable numérica: <?php echo $num; ?><br/>
Texto: <?php echo $texto; ?><br/>
<?php
echo 'Podemos intercalar blade con PHP estándar.' . '<br>';
?>

<?php if($num > 0): ?>
    <input type="text" name="caja" value="">
    <input type="submit" name="Aceptar" value="Aceptar">
    <br>
<?php else: ?>
    <p>Esto va en el else</p>
    <input type="text" name="else" value="else">
    <br>
<?php endif; ?>
Valor del vector:
<?php $__currentLoopData = $vector; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $valor; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('maestra', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>