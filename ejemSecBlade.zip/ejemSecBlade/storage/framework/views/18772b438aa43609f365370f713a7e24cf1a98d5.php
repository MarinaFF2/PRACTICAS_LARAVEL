<!DOCTYPE html>
<html>
    <head>
        <title> <?php echo $__env->yieldContent('titulo'); ?> </title>

    </head>
    <body>

        <?php echo $__env->yieldContent('contenido'); ?>

        <footer>
            <p>©Copyleft.</p>
        </footer>
    </body>
</html>
