<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Persona; 
use App\Propiedad;
use App\Coche;

class miControlador extends Controller {

    public function verPersonas() {
        $pers = Persona::all(); //igual que select *

        $datos = [
            'pers' => $pers
        ];

        return view('vistapersonas', $datos);
    }

    public function buscarPersona(Request $req) {
        $dn = $req->get('DNIBuscado');
        $pers = Persona::where('DNI', $dn)->first(); //devilve el primero, sin first devuelve todos los resultados con ese dni

        $datos = [
            'pers' => $pers
        ];

        return view('resultadoBusqueda', $datos);
    }

    public function insertarPersonas(Request $req) {
        $dn = $req->get('DNI');
        $no = $req->get('Nombre');
        $tf = $req->get('Tfno');
        $ed = $req->get('Edad');

        $pe = new Persona;
        $pe->DNI = $dn;
        $pe->Nombre = $no;
        $pe->Tfno = $tf;
        $pe->edad = $ed;
        $mensaje = 'Inserción ok';
        try {
            $pe->save(); //aqui se hace la insercion
        } catch (\Exception $e) {
            $mensaje = 'Clave duplicada';
        }
        return view('resultadoInsercion', ['mens' => $mensaje]);
    }

    public function vermayores() {
        $pers = Persona::where('edad', '>', 18)
                ->orderBy('Nombre', 'asc')
                ->get();
        $datos = [
            'pers' => $pers
        ];

        return view('vistapersonasmayores', $datos);
    }

    public function verPersonasCoche() {
//        $p = Propiedad::first();
//        $p = $p->propiedad;
        //$p = Propiedad::first();
        //$p = $p->usuarios;
        //dd($p->propiedad);
        //se cruzan tablas
        $p = Propiedad::all();
        $vectorDatos = [];
        foreach ($p as $pe) {
            $pers = Persona::where('DNI', $pe->DNI)->first(); //aqui se cruzan
            if ($pers) {
                $vectorDatos[] = ['DNI' => $pe->DNI,
                    'Matricula' => $pe->Matricula,
                    'Nombre' => $pers->Nombre,
                    'Tfno' => $pers->Tfno,
                    'edad' => $pers->edad];
            }
        }
        //dd($vectorDatos);
        //dd($pers->Nombre);
        //dd($p->propiedad);
        //$p = Propiedad::first();
        //dd($p->usuarios);
        return view('verPersonasConCoche', ['pers' => $vectorDatos]);
    }

    public function verCoches() {
        $c = Coche::all();
        $datos = [
            'co' => $c
        ];

        return view('vistacoches', $datos);
    }

}
